export const languages = [
  {english: 'Sent to', marathi: 'ला पाठवले'},
  {
    english: 'Search for fruits, vegetables, grocery',
    marathi: 'फळे, भाज्या, किराणा माल शोधा',
  },
  {english: 'Category', marathi: 'श्रेणी'},
  {english: 'View all', marathi: 'सर्व पहा'},
  {english: 'Description', marathi: 'वर्णन'},
  {english: 'Nutrition facts', marathi: 'पोषण तथ्ये'},

  {english: 'Checkout', marathi: 'तपासा'},

  {english: 'Total price', marathi: 'एकूण किंमत'},
];
