export const dummyData = [
  {
    title: "Anise Aroma Art Bazar",
    url:
      "https://images.unsplash.com/photo-1572437660243-b326b77f3684?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    id: 1,
  },
  {
    title: "Food inside a Bowl",
    url:
      "https://images.unsplash.com/photo-1575429945689-86f705f56d40?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    id: 2,
  },
  {
    title: "Vegatable Salad",
    url:
      "https://images.unsplash.com/photo-1597629703704-fb0cba5a0f3a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
    description:
      "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    id: 3,
  },
];
