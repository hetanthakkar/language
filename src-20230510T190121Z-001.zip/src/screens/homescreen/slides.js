export const slides = [
  {
    image: require('../../../assets/c1.png'),
  },
  {
    image: require('../../../assets/c2.png'),
  },
  {
    image: require('../../../assets/c3.png'),
  },
];
