export const categories = [
  {
    id: 21,
    name: 'Foodgrain Oil & Masala',
    image: require('../../../assets/image1.png'),
  },
  {
    id: 22,
    name: 'Milk, Bread Breakfast',
    image: require('../../../assets/image4.png'),
  },
  {
    id: 23,
    name: 'Fresh Vegetables',
    image: require('../../../assets/image2.png'),
  },
  {
    id: 24,
    name: 'Fresh Fruites           ',
    image: require('../../../assets/image5.png'),
  },
  {
    id: 25,
    name: 'Eggs, Fish & Meat',
    image: require('../../../assets/image3.png'),
  },
  {
    id: 26,
    name: 'Medecines',
    image: require('../../../assets/image8.png'),
  },
  {
    id: 27,
    name: 'Baby Care',
    image: require('../../../assets/image6.png'),
  },
  {
    id: 28,
    name: 'Pet Care',
    image: require('../../../assets/image7.png'),
  },
];
