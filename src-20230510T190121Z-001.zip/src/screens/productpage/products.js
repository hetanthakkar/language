export const products = [
  {
    id: 1,
    image: require('../../../assets/S1.png'),
    name: 'Aata',
  },
  {
    id: 2,
    image: require('../../../assets/S2.png'),
    name: 'Oil, Ghee & Butter',
  },
  {
    id: 3,
    image: require('../../../assets/S3.png'),
    name: 'Rice',
  },
  {
    id: 4,
    image: require('../../../assets/S4.png'),
    name: 'Rajma & Chole',
  },
  {
    id: 5,
    image: require('../../../assets/S5.png'),
    name: 'Urhad & Chana',
  },
];
