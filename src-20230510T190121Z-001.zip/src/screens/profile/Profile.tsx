// import {
//   Alert,
//   Modal,
//   Pressable,
//   StyleSheet,
//   Text,
//   TouchableOpacity,
//   View,
// } from 'react-native';
// import React, {useState} from 'react';
// import {useTranslation} from 'react-i18next';
// import i18next from 'i18next';

// import {useSelector, useDispatch} from 'react-redux';
// import {setLanguage} from '../../redux/action';

// const Profile = () => {
//   const LANGUAGES = [
//     {code: 'en', label: 'English'},
//     {code: 'mr', label: 'मराठी'},
//   ];
//   const dispatch = useDispatch();
//   const selectedLanguageCode = useSelector(state => state.language);

//   const setLanguageHandler = code => {
//     dispatch(setLanguage(code));
//   };

//   return (
//     <View
//       style={{
//         justifyContent: 'center',
//         alignItems: 'center',
//         marginTop: 30,
//       }}>
//       <Text>Hey!</Text>
//       <Text>Select language:</Text>
//       <TouchableOpacity>
//         <Text>{selectedLanguageCode}</Text>
//       </TouchableOpacity>
//       <View>
//         {LANGUAGES.map(language => {
//           const selectedLanguage = language.code === selectedLanguageCode;
//           return (
//             <Pressable
//               key={language.code}
//               style={{
//                 marginTop: 10,
//                 backgroundColor: selectedLanguage ? 'green' : 'white',
//               }}
//               onPress={() => setLanguageHandler(language.code)}>
//               <Text>{language.label}</Text>
//             </Pressable>
//           );
//         })}
//       </View>
//     </View>
//   );
// };

// export default Profile;
// import {StyleSheet, Text, View} from 'react-native';
// import React, {useState} from 'react';
// import Voice from '@react-native-voice/voice';

// const Profile = () => {
//   const [result, setResult] = useState('');
//   const [error, setError] = useState('');
//   const [isRecording, setIsRecording] = useState(false);

//   Voice.onSpeechStart = () => {
//     setIsRecording(true);
//   };
//   Voice.onSpeechEnd = () => {
//     setIsRecording(false);
//   };
//   Voice.onSpeechError = err => {
//     setError(err.error);
//   };
//   Voice.onSpeechResults = result => {
//     setResult(result.value[0]);
//   };

//   const stopRecording = async () => {
//     try {
//       await Voice.stop();
//     } catch (error) {
//       setError(error);
//     }
//   };
//   const startRecording = async () => {
//     try {
//       await Voice.start('en-US');
//     } catch (err) {
//       setError(err);
//     }
//   };
//   return (
//     <View>
//       <Text>Profile</Text>
//     </View>
//   );
// };

// export default Profile;

// const styles = StyleSheet.create({});
import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const Profile = () => {
  return (
    <View>
      <Text>Profile</Text>
    </View>
  );
};

export default Profile;

const styles = StyleSheet.create({});
