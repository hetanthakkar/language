export const ADD_TO_CART = 'add_to_cart';
export const DELETE_TO_CART = 'delete_to_cart';
export const SET_LANGUAGE = 'SET_LANGUAGE';
