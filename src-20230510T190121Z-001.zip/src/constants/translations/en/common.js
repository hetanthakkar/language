export default {
  Hey: 'hello',
  languageSelector: 'Select Language',
  Category: 'Category',
  PlaceHolder: 'Search for fruits, vegetables, grocery',
};
