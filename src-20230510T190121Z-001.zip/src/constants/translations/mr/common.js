export default {
  Hey: 'नमस्कार',
  languageSelector: 'भाषा निवडा',
  Category: 'श्रेणी',
  PlaceHolder: 'फळे, भाज्या, किराणा माल शोधा',
};
